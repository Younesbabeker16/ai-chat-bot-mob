import * as React from 'react';
import { ScrollView } from '@nativescript/core';
import { ChatMessage } from './ChatMessage';
import { Message } from '../../types/chat';
import { scrollToBottom } from '../../utils/scrollHelper';

interface MessageListProps {
  messages: Message[];
}

export function MessageList({ messages }: MessageListProps) {
  const scrollView = React.useRef<ScrollView>();

  React.useEffect(() => {
    scrollToBottom(scrollView.current);
  }, [messages]);

  return (
    <scrollView ref={scrollView}>
      <stackLayout>
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
      </stackLayout>
    </scrollView>
  );
}
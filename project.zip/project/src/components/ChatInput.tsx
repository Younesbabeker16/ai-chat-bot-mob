import * as React from 'react';
import { TextField } from '@nativescript/core';
import { ChatInputProps } from '../types/chat';

export function ChatInput({ onSendMessage, disabled = false }: ChatInputProps) {
  const [message, setMessage] = React.useState('');
  const textField = React.useRef<TextField>();

  const handleSubmit = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
      textField.current?.dismissSoftInput();
    }
  };

  return (
    <flexboxLayout className="border-t border-gray-200 p-2">
      <gridLayout columns="*, auto" className="w-full">
        <textField
          col="0"
          className={`border rounded-lg p-2 ${disabled ? 'opacity-50' : ''}`}
          hint="Type a message..."
          text={message}
          onTextChange={(args) => setMessage(args.value)}
          returnKeyType="send"
          onReturnPress={handleSubmit}
          ref={textField}
          isEnabled={!disabled}
        />
        <button
          col="1"
          className={`bg-blue-500 text-white rounded-lg p-2 ml-2 ${disabled ? 'opacity-50' : ''}`}
          text="Send"
          onTap={handleSubmit}
          isEnabled={!disabled}
        />
      </gridLayout>
    </flexboxLayout>
  );
}
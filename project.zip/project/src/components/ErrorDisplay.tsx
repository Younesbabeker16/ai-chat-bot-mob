import * as React from 'react';
import { AppError } from '../types/errors';

interface ErrorDisplayProps {
  error: AppError;
  onRetry?: () => void;
}

export function ErrorDisplay({ error, onRetry }: ErrorDisplayProps) {
  const getErrorColor = () => {
    switch (error.type) {
      case 'NETWORK_ERROR':
        return 'bg-orange-100 border-orange-500 text-orange-700';
      case 'API_ERROR':
        return 'bg-red-100 border-red-500 text-red-700';
      case 'VALIDATION_ERROR':
        return 'bg-yellow-100 border-yellow-500 text-yellow-700';
      case 'AUTH_ERROR':
        return 'bg-purple-100 border-purple-500 text-purple-700';
      default:
        return 'bg-gray-100 border-gray-500 text-gray-700';
    }
  };

  return (
    <flexboxLayout className={`border-l-4 p-4 ${getErrorColor()}`}>
      <stackLayout>
        <label className="font-bold" textWrap={true}>{error.type}</label>
        <label textWrap={true}>{error.message}</label>
        {error.code && (
          <label className="text-sm opacity-75" textWrap={true}>
            Error Code: {error.code}
          </label>
        )}
        {onRetry && (
          <button
            className="bg-white border rounded-lg px-4 py-2 mt-2"
            text="Try Again"
            onTap={onRetry}
          />
        )}
      </stackLayout>
    </flexboxLayout>
  );
}
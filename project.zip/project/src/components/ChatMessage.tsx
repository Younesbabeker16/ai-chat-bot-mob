import * as React from 'react';
import { ChatMessageProps } from '../types/chat';

export function ChatMessage({ message }: ChatMessageProps) {
  const containerClass = message.isUser ? 'ml-auto bg-blue-500' : 'mr-auto bg-gray-500';
  const statusClass = message.status === 'sending' ? 'opacity-50' : '';

  return (
    <flexboxLayout className={`rounded-lg p-3 max-w-3/4 m-2 ${containerClass} ${statusClass}`}>
      <stackLayout>
        <label className="text-white text-base" textWrap={true}>
          {message.text}
        </label>
        {message.status === 'sending' && (
          <label className="text-white text-xs opacity-75" textWrap={true}>
            Sending...
          </label>
        )}
      </stackLayout>
    </flexboxLayout>
  );
}
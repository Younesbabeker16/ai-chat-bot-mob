import * as React from 'react';
import { ScrollView } from '@nativescript/core';
import { ChatMessage } from '../components/ChatMessage';
import { ChatInput } from '../components/ChatInput';
import { ErrorDisplay } from '../components/ErrorDisplay';
import { useChat } from '../hooks/useChat';
import { scrollToBottom } from '../utils/scrollHelper';
import { AppError } from '../types/errors';

export function ChatScreen() {
  const { messages, handleSendMessage, error, retry } = useChat();
  const scrollView = React.useRef<ScrollView>();

  React.useEffect(() => {
    scrollToBottom(scrollView.current);
  }, [messages]);

  return (
    <gridLayout rows="*, auto">
      <scrollView row="0" ref={scrollView}>
        <stackLayout>
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
          {error && (
            <ErrorDisplay error={error} onRetry={retry} />
          )}
        </stackLayout>
      </scrollView>
      <ChatInput row="1" onSendMessage={handleSendMessage} />
    </gridLayout>
  );
}
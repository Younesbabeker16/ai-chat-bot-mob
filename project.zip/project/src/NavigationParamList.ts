export type MainStackParamList = {
  Chat: undefined;
};
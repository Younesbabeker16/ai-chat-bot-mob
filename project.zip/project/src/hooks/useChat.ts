import { useCallback, useState } from 'react';
import { useChatStore } from '../stores/chatStore';
import { generateAIResponse } from '../services/chatService';
import { AppError, AppException } from '../types/errors';
import { createError, ErrorType } from '../utils/errorHandler';
import { Message } from '../types/chat';

export const useChat = () => {
  const { messages, addMessage, updateMessage } = useChatStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<AppError | null>(null);
  const [pendingMessage, setPendingMessage] = useState<string | null>(null);

  const handleSendMessage = useCallback(async (text: string) => {
    setError(null);
    setIsLoading(true);
    setPendingMessage(text);
    
    const messageId = Date.now().toString();
    const newMessage: Message = {
      id: messageId,
      text,
      isUser: true,
      timestamp: new Date(),
      status: 'sending'
    };
    
    addMessage(newMessage);
    
    try {
      const aiResponse = await generateAIResponse(text);
      updateMessage(messageId, { status: 'sent' });
      addMessage({
        id: Date.now().toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date(),
        status: 'sent'
      });
      setPendingMessage(null);
    } catch (err) {
      let appError: AppError;
      
      if (err instanceof AppException) {
        appError = createError(err.type, err.message, err.code, err.details);
      } else {
        appError = createError(
          ErrorType.UNKNOWN,
          'Failed to process your message',
          'UNK_002'
        );
      }
      
      updateMessage(messageId, { status: 'error' });
      setError(appError);
    } finally {
      setIsLoading(false);
    }
  }, [addMessage, updateMessage]);

  const retry = useCallback(() => {
    if (pendingMessage) {
      handleSendMessage(pendingMessage);
    }
  }, [pendingMessage, handleSendMessage]);

  return {
    messages,
    handleSendMessage,
    error,
    retry,
    isLoading
  };
};
export interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'error';
}

export interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

export interface ChatMessageProps {
  message: Message;
}

export interface ChatState {
  isLoading: boolean;
  error: Error | null;
  messages: Message[];
}
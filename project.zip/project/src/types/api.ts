export interface AIResponse {
  text: string;
  timestamp: Date;
}

export interface ApiErrorResponse {
  message: string;
  statusCode: number;
}
import { AIResponse } from '../../types/api';
import { handleApiError } from '../utils/errorHandler';

const API_ENDPOINT = 'https://api.example.com/chat';

export async function sendChatMessage(message: string): Promise<AIResponse> {
  try {
    // Placeholder for actual API call
    return {
      text: `AI response to: ${message}`,
      timestamp: new Date(),
    };
  } catch (error) {
    throw handleApiError(error);
  }
}
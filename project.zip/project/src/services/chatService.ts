import { AppException, ErrorType } from '../types/errors';

export async function generateAIResponse(message: string): Promise<string> {
  try {
    if (!message.trim()) {
      throw new AppException(
        ErrorType.VALIDATION,
        'Message cannot be empty',
        'VAL_001'
      );
    }

    // Simulate API call with potential errors
    const random = Math.random();
    if (random < 0.2) {
      throw new AppException(
        ErrorType.NETWORK,
        'Failed to connect to AI service',
        'NET_001'
      );
    }
    if (random < 0.4) {
      throw new AppException(
        ErrorType.API,
        'AI service is currently unavailable',
        'API_503'
      );
    }

    // Simulate successful response
    await new Promise(resolve => setTimeout(resolve, 1000));
    return `AI response to: ${message}`;
  } catch (error) {
    if (error instanceof AppException) {
      throw error;
    }
    throw new AppException(
      ErrorType.UNKNOWN,
      'An unexpected error occurred while generating AI response',
      'UNK_001'
    );
  }
}
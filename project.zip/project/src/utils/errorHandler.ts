import { ErrorType, AppError } from '../types/errors';

export class AppException extends Error {
  constructor(
    public type: ErrorType,
    message: string,
    public code?: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'AppException';
  }
}

export function createError(
  type: ErrorType,
  message: string,
  code?: string,
  details?: Record<string, unknown>
): AppError {
  return {
    type,
    message,
    code,
    timestamp: new Date(),
    details
  };
}

export function handleNetworkError(error: unknown): AppError {
  if (error instanceof TypeError && error.message === 'Failed to fetch') {
    return createError(
      ErrorType.NETWORK,
      'Unable to connect to the server. Please check your internet connection.',
      'NET_001'
    );
  }
  return createError(
    ErrorType.NETWORK,
    'A network error occurred. Please try again.',
    'NET_002'
  );
}

export function handleApiError(error: unknown): AppError {
  if (error instanceof Response) {
    switch (error.status) {
      case 400:
        return createError(
          ErrorType.VALIDATION,
          'Invalid request. Please check your input.',
          'API_400'
        );
      case 401:
        return createError(
          ErrorType.AUTHENTICATION,
          'Authentication required. Please log in.',
          'API_401'
        );
      case 403:
        return createError(
          ErrorType.AUTHENTICATION,
          'Access denied. You don\'t have permission to perform this action.',
          'API_403'
        );
      case 404:
        return createError(
          ErrorType.API,
          'The requested resource was not found.',
          'API_404'
        );
      case 429:
        return createError(
          ErrorType.API,
          'Too many requests. Please try again later.',
          'API_429'
        );
      case 500:
        return createError(
          ErrorType.API,
          'Server error. Please try again later.',
          'API_500'
        );
      default:
        return createError(
          ErrorType.UNKNOWN,
          'An unexpected error occurred.',
          'API_000'
        );
    }
  }
  return createError(
    ErrorType.UNKNOWN,
    'An unexpected error occurred.',
    'API_000'
  );
}
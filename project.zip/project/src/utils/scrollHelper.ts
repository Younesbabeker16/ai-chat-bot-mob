import { ScrollView } from '@nativescript/core';

export const scrollToBottom = (scrollView: ScrollView | null): void => {
  if (scrollView) {
    scrollView.scrollToVerticalOffset(scrollView.scrollableHeight, true);
  }
};